/* 
AIRBNB DATA MART — MYSQL SCHEMA
Course: DLBDSPBDM01 - Data Mart Project 
in SQL
24 entities | 3 triple relationships 
(Payment, Review, Message)
1 recursive relationship 
(UserAccount.ReferredByUserID)
 */
CREATE DATABASE IF NOT EXISTS 
AirbnbDataMart

CHARACTER SET utf8mb4 COLLATE 
utf8mb4_unicode_ci;

USE AirbnbDataMart;

/* 1. Reference / lookup 
entities  */
CREATE TABLE Currency (
    CurrencyID      INT AUTO_INCREMENT 
PRIMARY KEY,
    CurrencyCode    CHAR(3) NOT NULL 
UNIQUE,      -- ISO 4217 code, e.g. EUR
    CurrencyName    VARCHAR(50) NOT NULL
);

CREATE TABLE PayoutMethod (
    PayoutMethodID  INT AUTO_INCREMENT 
PRIMARY KEY,
    MethodName      VARCHAR(50) NOT 
NULL,        -- Bank transfer, PayPal, ...
    Details         VARCHAR(200) NULL
);

CREATE TABLE PropertyType (
    PropertyTypeID  INT AUTO_INCREMENT 
PRIMARY KEY,
    TypeName        VARCHAR(50) NOT NULL 
UNIQUE  -- Entire home, Private room, Shared room
);

CREATE TABLE Address (
    AddressID       INT AUTO_INCREMENT 
PRIMARY KEY,
    Street          VARCHAR(100) NOT NULL,
    City            VARCHAR(50)  NOT NULL,
    StateProvince   VARCHAR(50)  NULL,
    Country         VARCHAR(50)  NOT NULL,
    PostalCode      VARCHAR(15)  NULL,
    Latitude        DECIMAL(9,6)  NULL,
    Longitude       DECIMAL(9,6)  NULL
);

CREATE TABLE CancellationPolicy (
    CancellationPolicyID INT AUTO_INCREMENT 
PRIMARY KEY,
    PolicyName           VARCHAR(30) NOT 
NULL,   -- Flexible, Moderate, Strict
    RefundPercentage     DECIMAL(5,2) NOT 
NULL,
    DaysBeforeCheckIn    INT NOT NULL
);

CREATE TABLE Amenity (
    AmenityID       INT AUTO_INCREMENT 
PRIMARY KEY,
    AmenityName     VARCHAR(50) NOT NULL 
UNIQUE
);

/* 2. Identity entities  */
CREATE TABLE UserAccount (
    UserID  INT AUTO_INCREMENT 
PRIMARY KEY,
    FirstName   VARCHAR(50) NOT 
NULL,
    LastName  VARCHAR(50) NOT 
NULL,
    Email   VARCHAR(100) NOT 
NULL UNIQUE,
    Phone   VARCHAR(20) NULL,
    DateJoined  DATE NOT NULL,
    ReferredByUserID  INT 
NULL,                 -- recursive relationship (self-FK)
    CONSTRAINT FK_User_ReferredBy FOREIGN 
KEY (ReferredByUserID) REFERENCES 
UserAccount(UserID)
);

CREATE TABLE GuestProfile (
    GuestID             INT AUTO_INCREMENT 
PRIMARY KEY,
    UserID              INT NOT NULL 
UNIQUE,      -- 1:1 with UserAccount
    IDVerified          TINYINT(1) NOT NULL 
DEFAULT 0,
    PreferredCurrencyID INT NOT NULL,
    Bio                 VARCHAR(500) NULL,
    CONSTRAINT FK_Guest_User FOREIGN KEY 
(UserID) REFERENCES UserAccount(UserID),
    CONSTRAINT FK_Guest_Currency FOREIGN 
KEY (PreferredCurrencyID) REFERENCES 
Currency(CurrencyID)
);

CREATE TABLE HostProfile (
    HostID              INT AUTO_INCREMENT 
PRIMARY KEY,
    UserID              INT NOT NULL 
UNIQUE,      -- 1:1 with UserAccount
    ProfileDescription  VARCHAR(500) NULL,
    ResponseRatePct     DECIMAL(5,2) NOT 
NULL DEFAULT 100,
    PayoutMethodID      INT NOT NULL,
    CONSTRAINT FK_Host_User FOREIGN KEY 
(UserID) REFERENCES UserAccount(UserID),
    CONSTRAINT FK_Host_PayoutMethod FOREIGN 
KEY (PayoutMethodID) REFERENCES 
PayoutMethod(PayoutMethodID)
);

CREATE TABLE SocialNetworkLink (
    SocialLinkID    INT AUTO_INCREMENT 
PRIMARY KEY,
    UserID          INT NOT NULL,
    NetworkName     VARCHAR(50) NOT 
NULL,        -- Facebook, Instagram, ...
    ProfileURL      VARCHAR(200) NOT NULL,
    LinkedDate      DATE NOT NULL,
    CONSTRAINT FK_Social_User FOREIGN KEY 
(UserID) REFERENCES UserAccount(UserID)
);

/*  3. Property entities  */
CREATE TABLE Property (
    PropertyID           INT AUTO_INCREMENT 
PRIMARY KEY,
    HostID               INT NOT NULL,
    PropertyTypeID       INT NOT NULL,
    AddressID            INT NOT NULL,
    CancellationPolicyID INT NOT NULL,
    Title                VARCHAR(100) NOT 
NULL,
    Description          VARCHAR(1000) 
NULL,
    PricePerNight        DECIMAL(8,2) NOT 
NULL,
    MaxGuests            INT NOT NULL,
    CreatedDate          DATE NOT NULL,
    CONSTRAINT FK_Property_Host FOREIGN KEY 
(HostID) REFERENCES HostProfile(HostID),
    CONSTRAINT FK_Property_Type FOREIGN KEY 
(PropertyTypeID) REFERENCES 
PropertyType(PropertyTypeID),
    CONSTRAINT FK_Property_Address FOREIGN 
KEY (AddressID) REFERENCES 
Address(AddressID),
    CONSTRAINT FK_Property_Cancellation 
FOREIGN KEY (CancellationPolicyID) 
REFERENCES 
CancellationPolicy(CancellationPolicyID)
);

CREATE TABLE PropertyPhoto (
    PhotoID         INT AUTO_INCREMENT 
PRIMARY KEY,
    PropertyID      INT NOT NULL,
    PhotoURL        VARCHAR(200) NOT NULL,
    UploadDate      DATE NOT NULL,
    IsCoverPhoto    TINYINT(1) NOT NULL 
DEFAULT 0,
    CONSTRAINT FK_Photo_Property FOREIGN 
KEY (PropertyID) REFERENCES 
Property(PropertyID)
);

CREATE TABLE PropertyAmenity (
-- M:N junction
    PropertyID      INT NOT NULL,
    AmenityID       INT NOT NULL,
    PRIMARY KEY (PropertyID, AmenityID),
    CONSTRAINT FK_PropAmenity_Property 
FOREIGN KEY (PropertyID) REFERENCES 
Property(PropertyID),
    CONSTRAINT FK_PropAmenity_Amenity 
FOREIGN KEY (AmenityID) REFERENCES 
Amenity(AmenityID)
);

/* 4. Booking & money entities */
CREATE TABLE Booking (
    BookingID       INT AUTO_INCREMENT 
PRIMARY KEY,
    PropertyID      INT NOT NULL,
    GuestID         INT NOT NULL,
    CurrencyID      INT NOT NULL,
    CheckInDate     DATE NOT NULL,
    CheckOutDate    DATE NOT NULL,
    NumGuests       INT NOT NULL,
    BookingStatus   VARCHAR(20) NOT NULL, -- Confirmed, Cancelled, Completed
    BookingDate     DATE NOT NULL,
    CONSTRAINT FK_Booking_Property FOREIGN 
KEY (PropertyID) REFERENCES 
Property(PropertyID),
    CONSTRAINT FK_Booking_Guest FOREIGN KEY 
(GuestID) REFERENCES GuestProfile(GuestID),
    CONSTRAINT FK_Booking_Currency FOREIGN 
KEY (CurrencyID) REFERENCES 
Currency(CurrencyID)
);

CREATE TABLE PromoCode (
    PromoCodeID     INT AUTO_INCREMENT 
PRIMARY KEY,
    Code            VARCHAR(20) NOT NULL 
UNIQUE,
    DiscountPercentage DECIMAL(5,2) NOT 
NULL,
    ValidFrom       DATE NOT NULL,
    ValidTo         DATE NOT NULL
);

CREATE TABLE BookingPromo (          
-- M:N junction
    BookingID  INT NOT NULL,
    PromoCodeID  INT NOT NULL,
    PRIMARY KEY (BookingID, PromoCodeID),
    CONSTRAINT FK_BookingPromo_Booking 
FOREIGN KEY (BookingID) REFERENCES 
Booking(BookingID),
    CONSTRAINT FK_BookingPromo_Promo 
FOREIGN KEY (PromoCodeID) REFERENCES 
PromoCode(PromoCodeID)
);

/* TRIPLE RELATIONSHIP #1: a Payment joins 
 Booking + paying Guest + receiving Host */
CREATE TABLE Payment (
    PaymentID       INT AUTO_INCREMENT 
PRIMARY KEY,
    BookingID       INT NOT NULL,
    GuestID         INT NOT NULL, -- payer
    HostID          INT NOT NULL, -- payee
    Amount          DECIMAL(10,2) NOT NULL,
    PaymentDate     DATE NOT NULL,
    PayoutDate      DATE NULL, -- host paid 24h after guest arrival
    PaymentStatus   VARCHAR(20) NOT NULL, -- Pending, Paid, Refunded
    CONSTRAINT FK_Payment_Booking FOREIGN 
KEY (BookingID) REFERENCES 
Booking(BookingID),
    CONSTRAINT FK_Payment_Guest FOREIGN KEY 
(GuestID) REFERENCES GuestProfile(GuestID),
    CONSTRAINT FK_Payment_Host FOREIGN KEY 
(HostID) REFERENCES HostProfile(HostID)
);

CREATE TABLE Commission (
    CommissionID  INT AUTO_INCREMENT 
PRIMARY KEY,
    PaymentID  INT NOT NULL 
UNIQUE,
    GuestCommissionPct  DECIMAL(5,2) NOT NULL,   -- 6-12%
    HostCommissionPct   DECIMAL(5,2) NOT NULL,   -- 3%
    CommissionAmount    DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_Commission_Payment 
FOREIGN KEY (PaymentID) REFERENCES 
Payment(PaymentID)
);

/* 5. Engagement entities */
/* TRIPLE RELATIONSHIP #2: a Review joins Booking + Reviewer + Reviewee (guest-host, per stay) */
CREATE TABLE Review (
    ReviewID        INT AUTO_INCREMENT 
PRIMARY KEY,
    BookingID       INT NOT NULL,
    ReviewerUserID  INT NOT NULL,
    RevieweeUserID  INT NOT NULL,
    Rating          INT NOT NULL CHECK 
(Rating BETWEEN 1 AND 5),
    Comment         VARCHAR(500) NULL,
    ReviewDate      DATE NOT NULL,
    CONSTRAINT FK_Review_Booking FOREIGN 
KEY (BookingID) REFERENCES 
Booking(BookingID),
    CONSTRAINT FK_Review_Reviewer FOREIGN 
KEY (ReviewerUserID) REFERENCES 
UserAccount(UserID),
    CONSTRAINT FK_Review_Reviewee FOREIGN 
KEY (RevieweeUserID) REFERENCES 
UserAccount(UserID)
);

/* TRIPLE RELATIONSHIP #3: a message joins 
Sender + Receiver + the Property it's all about */
CREATE TABLE Message (
    MessageID       INT AUTO_INCREMENT 
PRIMARY KEY,
    SenderUserID    INT NOT NULL,
    ReceiverUserID  INT NOT NULL,
    PropertyID      INT NOT NULL,
    MessageText     VARCHAR(500) NOT NULL,
    SentDate        DATETIME NOT NULL,
    IsRead          TINYINT(1) NOT NULL 
DEFAULT 0,
    CONSTRAINT FK_Message_Sender FOREIGN 
KEY (SenderUserID) REFERENCES 
UserAccount(UserID),
    CONSTRAINT FK_Message_Receiver FOREIGN 
KEY (ReceiverUserID) REFERENCES 
UserAccount(UserID),
    CONSTRAINT FK_Message_Property FOREIGN 
KEY (PropertyID) REFERENCES 
Property(PropertyID)
);

CREATE TABLE Wishlist (
    WishlistID      INT AUTO_INCREMENT 
PRIMARY KEY,
    GuestID         INT NOT NULL,
    WishlistName    VARCHAR(50) NOT NULL,
    CreatedDate     DATE NOT NULL,
    CONSTRAINT FK_Wishlist_Guest FOREIGN 
KEY (GuestID) REFERENCES 
GuestProfile(GuestID)
);

CREATE TABLE WishlistItem (             
-- M:N junction
    WishlistID      INT NOT NULL,
    PropertyID      INT NOT NULL,
    AddedDate       DATE NOT NULL,
    PRIMARY KEY (WishlistID, PropertyID),
    CONSTRAINT FK_WishlistItem_Wishlist 
FOREIGN KEY (WishlistID) REFERENCES 
Wishlist(WishlistID),
    CONSTRAINT FK_WishlistItem_Property 
FOREIGN KEY (PropertyID) REFERENCES 
Property(PropertyID)
);

CREATE TABLE IncomeEstimate (
    IncomeEstimateID        INT 
AUTO_INCREMENT PRIMARY KEY,
    PropertyID              INT NOT NULL,
    EstimatedMonthlyIncome  DECIMAL(10,2) 
NOT NULL,
    OccupancyRatePct        DECIMAL(5,2) 
NOT NULL,
    EstimateDate            DATE NOT NULL,
    CONSTRAINT FK_Income_Property FOREIGN 
KEY (PropertyID) REFERENCES 
Property(PropertyID)
);

CREATE TABLE Notification (
    NotificationID      INT AUTO_INCREMENT 
PRIMARY KEY,
    UserID              INT NOT NULL,
    NotificationType    VARCHAR(30) NOT 
NULL,   -- BookingConfirmed, NewMessage, ReviewReceived, Payout
    Message             VARCHAR(200) NOT 
NULL,
    CreatedDate         DATETIME NOT NULL,
    IsRead              TINYINT(1) NOT NULL 
DEFAULT 0,
    CONSTRAINT FK_Notification_User FOREIGN 
KEY (UserID) REFERENCES UserAccount(UserID)
);

/* 
AIRBNB DATA MART — MYSQL DUMMY DATA 
(>=20 rows per table) */
-- Currency
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (1, 
'EUR', 'Euro');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (2, 
'USD', 'US Dollar');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (3, 
'GBP', 'British Pound');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (4, 
'CHF', 'Swiss Franc');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (5, 
'SEK', 'Swedish Krona');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (6, 
'PLN', 'Polish Zloty');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (7, 
'DKK', 'Danish Krone');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (8, 
'NOK', 'Norwegian Krone');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (9, 
'CZK', 'Czech Koruna');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (10, 
'HUF', 'Hungarian Forint');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (11, 
'JPY', 'Japanese Yen');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (12, 
'CAD', 'Canadian Dollar');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (13, 
'AUD', 'Australian Dollar');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (14, 
'BRL', 'Brazilian Real');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (15, 
'MXN', 'Mexican Peso');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (16, 
'TRY', 'Turkish Lira');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (17, 
'ZAR', 'South African Rand');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (18, 
'SGD', 'Singapore Dollar');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (19, 
'NZD', 'New Zealand Dollar');
INSERT INTO Currency (CurrencyID, 
CurrencyCode, CurrencyName) VALUES (20, 
'AED', 'UAE Dirham');

-- PayoutMethod
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (1, 'Bank 
transfer', 'SEPA / SWIFT transfer to host 
bank account');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (2, 'PayPal', 
'Payout via PayPal balance');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (3, 'Debit 
card', 'Instant payout to linked debit 
card');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (4, 'Payoneer', 
'International payout via Payoneer');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (5, 'Wire 
transfer', 'Manual wire transfer, 3-5 
business days');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (6, 'Revolut', 
'Payout to linked Revolut account');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (7, 'Wise', 
'Payout via Wise multi-currency account');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (8, 'Skrill', 
'Payout via Skrill e-wallet');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (9, 'Venmo', 
'Payout via Venmo (US only)');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (10, 'Apple 
Pay', 'Instant payout to Apple Pay 
wallet');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (11, 'Google 
Pay', 'Instant payout to Google Pay 
wallet');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (12, 'Credit 
union transfer', 'Transfer to a local 
credit union account');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (13, 'Prepaid 
card', 'Payout loaded onto a prepaid debit 
card');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (14, 'Check by 
mail', 'Physical check mailed to host 
address');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (15, 'Alipay', 
'Payout via Alipay wallet');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (16, 'WeChat 
Pay', 'Payout via WeChat Pay wallet');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (17, 'M-Pesa', 
'Mobile money payout via M-Pesa');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (18, 'Stripe 
balance', 'Held in Stripe Connect 
balance');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (19, 'Cash 
pickup', 'Cash pickup at a partner 
location');
INSERT INTO PayoutMethod (PayoutMethodID, 
MethodName, Details) VALUES (20, 
'Cryptocurrency', 'Payout in stablecoin to 
a linked wallet');

-- PropertyType
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (1, 'Entire home/apt');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (2, 'Private room');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (3, 'Shared room');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (4, 'Unique stay');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (5, 'Apartment');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (6, 'Villa');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (7, 'Cabin');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (8, 'Cottage');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (9, 'Loft');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (10, 'Bungalow');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (11, 'Farmhouse');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (12, 'Houseboat');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (13, 'Treehouse');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (14, 'Guesthouse');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (15, 'Townhouse');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (16, 'Chalet');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (17, 'Studio');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (18, 'Condominium');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (19, 'Bed and breakfast');
INSERT INTO PropertyType (PropertyTypeID, 
TypeName) VALUES (20, 'Tiny house');

-- Address
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (1, '164 Rua 
das Flores', 'Lisbon', 'Lisbon', 
'Portugal', '15592', 35.600258, -0.74912);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (2, '58 Carrer 
de Mallorca', 'Porto', 'Porto', 'Portugal', 
'19289', 52.675309, 11.300985);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (3, '140 Rue de 
Rivoli', 'Barcelona', 'Catalonia', 'Spain', 
'12395', 49.17182, -8.04652);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (4, '24 Via del 
Corso', 'Madrid', 'Madrid', 'Spain', 
'29657', 40.583861, 9.060562);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (5, '144 Unter 
den Linden', 'Paris', 'Ile-de-France', 
'France', '27062', 52.184471, 12.039749);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (6, '108 
Keizersgracht', 'Nice', 'Provence', 
'France', '29893', 45.781017, -0.654279);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (7, '2 Kärntner 
Strasse', 'Rome', 'Lazio', 'Italy', 
'21926', 51.755345, 1.207515);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (8, '40 
Wenceslas Square', 'Florence', 'Tuscany', 
'Italy', '29221', 57.973114, 1.097836);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (9, '24 Grafton 
Street', 'Berlin', 'Berlin', 'Germany', 
'50797', 37.321193, 16.424831);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (10, '155 Royal 
Mile', 'Munich', 'Bavaria', 'Germany', 
'35671', 54.371079, 12.891954);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (11, '138 Baker 
Street', 'Amsterdam', 'North Holland', 
'Netherlands', '17361', 58.354778, 
2.356031);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (12, '142 Ermou 
Street', 'Vienna', 'Vienna', 'Austria', 
'39427', 54.905712, 9.555593);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (13, '93 
Floriańska Street', 'Prague', 'Prague', 
'Czechia', '76674', 39.614926, -6.913346);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (14, '170 
Strøget', 'Dublin', 'Leinster', 'Ireland', 
'30871', 53.55364, 20.556646);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (15, '60 
Drottninggatan', 'Edinburgh', 'Scotland', 
'United Kingdom', '14238', 44.123029, 
4.602309);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (16, '94 
Alameda', 'London', 'England', 'United 
Kingdom', '22319', 43.884343, -2.714789);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (17, '69 
Passeig de Gracia', 'Athens', 'Attica', 
'Greece', '92988', 57.47971, 10.441062);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (18, '156 
Champs-Elysees', 'Krakow', 'Lesser Poland', 
'Poland', '84227', 39.107328, 12.873804);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (19, '42 Piazza 
Navona', 'Copenhagen', 'Capital Region', 
'Denmark', '61589', 44.106931, 20.685701);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (20, '164 
Marienplatz', 'Stockholm', 'Stockholm 
County', 'Sweden', '91198', 48.366794, 
11.538428);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (21, '15 Rua 
das Flores', 'Lisbon', 'Lisbon', 
'Portugal', '31021', 54.723262, 15.151374);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (22, '103 
Carrer de Mallorca', 'Porto', 'Porto', 
'Portugal', '36093', 36.588527, 18.394084);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (23, '146 Rue 
de Rivoli', 'Barcelona', 'Catalonia', 
'Spain', '95098', 42.552269, 10.66316);
INSERT INTO Address (AddressID, Street, 
City, StateProvince, Country, PostalCode, 
Latitude, Longitude) VALUES (24, '102 Via 
del Corso', 'Madrid', 'Madrid', 'Spain', 
'85259', 46.012444, -1.053595);

-- CancellationPolicy
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(1, 'Flexible', 100.0, 1);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(2, 'Moderate', 50.0, 5);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(3, 'Strict', 0.0, 14);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(4, 'Flexible Plus', 100.0, 2);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(5, 'Moderate Plus', 60.0, 6);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(6, 'Strict Plus', 10.0, 21);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(7, 'Super Strict 30', 0.0, 30);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(8, 'Super Strict 60', 0.0, 60);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(9, 'Long Term', 50.0, 30);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(10, 'Non-Refundable', 0.0, 0);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(11, 'Firm', 50.0, 30);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(12, 'Relaxed', 100.0, 0);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(13, 'Standard 48h', 100.0, 2);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(14, 'Standard 7d', 75.0, 7);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(15, 'Standard 14d', 50.0, 14);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(16, 'Business Flex', 90.0, 3);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(17, 'Seasonal Strict', 20.0, 45);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(18, 'Weekend Getaway', 80.0, 3);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(19, 'Extended Stay', 40.0, 21);
INSERT INTO CancellationPolicy 
(CancellationPolicyID, PolicyName, 
RefundPercentage, DaysBeforeCheckIn) VALUES 
(20, 'Event Peak Strict', 0.0, 90);

-- Amenity
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (1, 'WiFi');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (2, 'Kitchen');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (3, 'Washer');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (4, 'Free parking');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (5, 'Air 
conditioning');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (6, 'Heating');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (7, 'TV');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (8, 'Pool');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (9, 'Dedicated 
workspace');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (10, 'Hot tub');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (11, 'EV charger');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (12, 'Gym');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (13, 'Breakfast 
included');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (14, 'Fireplace');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (15, 'Elevator');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (16, 'Balcony');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (17, 'Pet friendly');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (18, 'Smoke alarm');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (19, 'First aid kit');
INSERT INTO Amenity (AmenityID, 
AmenityName) VALUES (20, 'Self check-in');

 /*UserAccount (recursive relationship: 
ReferredByUserID references another 
UserAccount) */
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (1, 'James', 
'Olusoji', 'james.Olusoji1@gmail.com', 
'+156899925830', '2020-11-22', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (2, 'Mary', 
'Adebanjo', 'mary.adebanjo2@gmail.com', 
'+412727694430', '2024-08-10', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (3, 'Kai', 
'Lee', 'kailee3@gmail.com', 
'+328528853029', '2023-02-13', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (4, 'George', 
'Ramirez', 'georgeramirez04@gmail.com', 
'+142248532577', '2026-06-06', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (5, 'John', 
'Clark', 'john.clark5@gmail.com', 
'+282197613238', '2016-01-21', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (6, 'Jennifer', 
'Brown', 'jennifer.brown6@gmail.com', 
'+86264112119', '2018-08-03', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (7, 'Funmi', 
'Okeowo', 
'funmi.okeowo7@gmail.com', 
'+378553290810', '2016-06-04', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (8, 'Linda', 
'Gold', 'linda.gold8@gmail.com', 
'+227509760584', '2025-07-01', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (9, 'Lekan', 
'Thompson', 'leken.thompson9@gmail.com', 
'+300369953851', '2015-04-05', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (10, 'Elizabeth', 
'Oyewunmi', 
'elizabethoyewunmi10@yahoo.com', 
'+378873869166', '2017-07-27', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (11, 'William', 
'Lux', 'william.lux11@gmail.com', 
'+379676567501', '2020-12-25', 6);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (12, 'Femi', 
'Brown', 'femibrown12@gamail.com', 
'+87415143362', '2024-10-01', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (13, 'Richard', 
'Coke', 
'richard.coke13@gmail.com', 
'+31875340444', '2020-11-27', 3);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (14, 'Susan', 
'Black', 'susan.black14@yahoo.com', 
'+289214257751', '2021-09-10', 9);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (15, 'Carpenter', 
'Harris', 'carpenter.harris15@gmail.com', 
'+341313579170', '2018-06-06', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (16, 'Jessica', 
'Abdullahi', 'jessica.abdullahi16@gmail.com', 
'+112679153816', '2015-01-05', 8);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (17, 'Basirat', 
'Juju', 'basirat.juju17@gmail.com', 
'+39220117054', '2023-02-21', 10);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (18, 'Happy', 
'Leo', 'happy.leo18@yahoo.com', 
'+152162196678', '2020-05-27', 3);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (19, 'Charles', 
'Greene', 
'charles.greene19@gmail.com', 
'+73885879795', '2025-11-25', 18);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (20, 'Ray', 
'Martin', 'ray.martin20@yahoo.com', 
'+94237859287', '2025-08-29', 6);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (21, 'Kemi', 
'Clark', 'kemi.clark21@gmail.com', 
'+165666585408', '2024-06-28', 18);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (22, 'Tina', 
'Owolabi', 'tinaowolabi22@yahoo.com', 
'+416883757514', '2019-07-06', 13);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (23, 'Matthew', 
'Bliss', 'matthew.bliss23@gmail.com', 
'+373797801251', '2023-05-18', 17);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID)
 VALUES (24, 'Lisa', 
'Sam', 'lisa.sam24@example.com', 
'+261229927269', '2020-07-23', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) 
VALUES (25, 'Tony', 
'Olaniyi', 
'tony.olaniyi25@gmail.com', 
'+203122585366', '2020-02-29', 1);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (26, 'Betty', 
'Perez', 'bettyperez26@gmail.com', 
'+66860038427', '2016-04-27', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (27, 'Mark', 
'Lewis', 'marklewis27@gmail.com', 
'+46454794895', '2016-08-03', 9);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (28, 'Margaret', 
'Scott', 'margaretscott28@gmail.com', 
'+372621209849', '2019-10-22', 24);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (29, 'Paul', 
'Williams', 'paulwilliams29@gmail.com', 
'+322718702544', '2025-08-08', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (30, 'Sandra', 
'Martinez', 
'sandramartinez30@gmail.com', 
'+272967043303', '2024-02-17', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (31, 'Steven', 
'Taylor', 'steven.taylor31@gmail.com', 
'+79807577342', '2024-09-01', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (32, 'Ashley', 
'White', 'ashley.white32@gmail.com', 
'+240601463916', '2016-03-19', 21);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (33, 'Kenji', 
'Walker', 'kenji.walker33@gmail.com', 
'+80165082363', '2024-01-12', 7);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (34, 'Yuki', 
'Nguyen', 'yukinguyen34@gmail.com', 
'+157305718272', '2019-04-08', 9);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (35, 'Mei', 
'Jones', 'mei.jones35@gmail.com', 
'+246297018781', '2021-03-31', 5);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (36, 'Hiro', 
'Lopez', 'hiro.lopez36@gmail.com', 
'+256967607278', '2017-03-13', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (37, 'Elena', 
'Jackson', 'elena.jackson37@gmail.com', 
'+306997677788', '2015-05-01', 16);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (38, 'Marco', 
'Sanchez', 'marco.sanchez38@gmail.com', 
'+115536383774', '2025-11-22', 26);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (39, 'Sofia', 
'Allen', 'sofia.allen39@gmail.com', 
'+60276777762', '2023-07-02', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (40, 'Luca', 
'Flores', 'luca.flores40@gmail.com', 
'+229384759615', '2025-03-16', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (41, 'Amara', 
'Miller', 'amara.miller41@gmail.com', 
'+386884374109', '2025-11-30', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (42, 'Kwame', 
'Wilson', 'kwame.wilson42@gmail.com', 
'+181333754555', '2016-04-24', 35);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (43, 'Fatima', 
'Lee', 'fatima.lee43@gmail.com', 
'+61903132646', '2022-01-13', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (44, 'Omar', 
'Ramirez', 'omar.ramirez44@gmail.com', 
'+329611947770', '2026-04-12', 34);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (45, 'Priya', 
'Wright', 'priyawright45@gmail.com', 
'+110161073976', '2026-05-23', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (46, 'Arjun', 
'Johnson', 'arjun.johnson46@gmail.com', 
'+125173574218', '2016-07-10', 16);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (47, 'Chloe', 
'Rodriguez', 
'chloe.rodriguez47@gmail.com', 
'+236228727266', '2020-07-09', 3);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (48, 'Noah', 
'Thomas', 'noah.thomas48@gmail.com', 
'+347188029013', '2024-05-27', 37);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (49, 'Ines', 
'Thompson', 'ines.thompson49@gmail.com', 
'+297439699535', '2020-11-06', NULL);
INSERT INTO UserAccount (UserID, FirstName, 
LastName, Email, Phone, DateJoined, 
ReferredByUserID) VALUES (50, 'Liam', 
'Robinson', 'liam.robinson50@gmail.com', 
'+396437352358', '2020-05-09', NULL);


-- HostProfile
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
 VALUES (1, 1, 'Experienced 
host welcoming travelers since 2018.', 
95.08, 10);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (2, 2, 'Experienced 
host welcoming travelers since 2023.', 
89.74, 3);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
 VALUES (3, 3, 'Experienced 
host welcoming travelers since 2016.', 
91.87, 19);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
 VALUES (4, 4, 'Experienced 
host welcoming travelers since 2017.', 
86.1, 7);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (5, 5, 'Experienced 
host welcoming travelers since 2020.', 
86.99, 12);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
 VALUES (6, 6, 'Experienced 
host welcoming travelers since 2017.', 
98.19, 12);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (7, 7, 'Experienced 
host welcoming travelers since 2020.', 
87.37, 18);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (8, 8, 'Experienced 
host welcoming travelers since 2020.', 
94.18, 17);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (9, 9, 'Experienced 
host welcoming travelers since 2016.', 
95.02, 18);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (10, 10, 
'Experienced host welcoming travelers since 
2020.', 98.98, 4);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (11, 11, 
'Experienced host welcoming travelers since 
2018.', 88.97, 4);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (12, 12, 
'Experienced host welcoming travelers since 
2018.', 89.09, 20);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (13, 13, 
'Experienced host welcoming travelers since 
2019.', 95.76, 7);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (14, 14, 
'Experienced host welcoming travelers since 
2020.', 92.58, 9);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
 VALUES (15, 15, 
'Experienced host welcoming travelers since 
2016.', 86.38, 14);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
 VALUES (16, 16, 
'Experienced host welcoming travelers since 
2020.', 85.66, 11);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) VALUES (17, 17, 
'Experienced host welcoming travelers since 
2018.', 94.56, 9);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
VALUES (18, 18, 
'Experienced host welcoming travelers since 
2018.', 96.12, 18);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID) 
VALUES (19, 19, 
'Experienced host welcoming travelers since 
2022.', 93.41, 4);
INSERT INTO HostProfile (HostID, UserID, 
ProfileDescription, ResponseRatePct, 
PayoutMethodID)
 VALUES (20, 20, 
'Experienced host welcoming travelers since 
2017.', 99.18, 5);

-- GuestProfile
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (1, 21, 1, 12, 'Loves exploring new 
cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (2, 22, 1, 5, 'Loves exploring new 
cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (3, 23, 1, 2, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (4, 24, 1, 2, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (5, 25, 0, 7, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (6, 26, 1, 4, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (7, 27, 1, 18, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (8, 28, 0, 14, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (9, 29, 0, 5, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (10, 30, 0, 8, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (11, 31, 0, 6, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (12, 32, 0, 1, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (13, 33, 1, 11, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (14, 34, 1, 14, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (15, 35, 0, 8, 'Loves exploring new 
cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (16, 36, 1, 4, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (17, 37, 1, 2, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (18, 38, 0, 8, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (19, 39, 1, 15, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (20, 40, 1, 8, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (21, 41, 1, 7, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (22, 42, 1, 9, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (23, 43, 0, 9, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (24, 44, 1, 17, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (25, 45, 1, 18, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (26, 46, 1, 1, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (27, 47, 1, 9, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (28, 48, 1, 9, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (29, 49, 1, 20, 'Loves exploring new cities and meeting local hosts.');
INSERT INTO GuestProfile (GuestID, UserID, 
IDVerified, PreferredCurrencyID, Bio) 
VALUES (30, 50, 1, 11, 'Loves exploring new cities and meeting local hosts.');


-- SocialNetworkLink
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (1, 28, 
'Instagram', 
'https://instagram.com/user28', '2024-08-06');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (2, 33, 
'LinkedIn', 'https://linkedin.com/user33', 
'2013-08-05');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (3, 25, 'X', 
'https://x.com/user25', '2023-12-07');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (4, 13, 
'Facebook', 'https://facebook.com/user13', 
'2016-09-17');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (5, 3, 
'Instagram', 'https://instagram.com/user3', 
'2020-10-12');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (6, 1, 
'LinkedIn', 'https://linkedin.com/user1', 
'2022-08-30');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (7, 35, 'X', 
'https://x.com/user35', '2026-05-28');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (8, 47, 
'Facebook', 'https://facebook.com/user47', 
'2026-01-15');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (9, 13, 
'Instagram', 
'https://instagram.com/user13', '2019-03-03');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (10, 28, 
'LinkedIn', 'https://linkedin.com/user28', 
'2012-07-27');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (11, 43, 
'X', 'https://x.com/user43', '2018-05-28');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (12, 40, 
'Facebook', 'https://facebook.com/user40', 
'2018-01-15');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (13, 43, 
'Instagram', 
'https://instagram.com/user43', '2013-10-17');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (14, 47, 
'LinkedIn', 'https://linkedin.com/user47', 
'2017-09-26');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (15, 33, 
'X', 'https://x.com/user33', '2017-12-08');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (16, 43, 
'Facebook', 'https://facebook.com/user43', 
'2020-02-28');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (17, 21, 
'Instagram', 
'https://instagram.com/user21', '2020-01-10');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (18, 45, 
'LinkedIn', 'https://linkedin.com/user45', 
'2017-08-19');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate)
VALUES (19, 36, 
'X', 'https://x.com/user36', '2013-11-08');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (20, 13, 
'Facebook', 'https://facebook.com/user13', 
'2020-06-06');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (21, 43, 
'Instagram', 
'https://instagram.com/user43', '2019-07-03');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (22, 44, 
'LinkedIn', 'https://linkedin.com/user44', 
'2014-11-26');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (23, 40, 
'X', 'https://x.com/user40', '2023-10-07');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (24, 20, 
'Facebook', 'https://facebook.com/user20', 
'2020-02-09');
INSERT INTO SocialNetworkLink 
(SocialLinkID, UserID, NetworkName, 
ProfileURL, LinkedDate) 
VALUES (25, 36, 
'Instagram', 
'https://instagram.com/user36', '2011-01-04');

-- Property
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (1, 1, 10, 1, 10, 'Cozy Studio near 
the Old Town', 'A wonderful stay: cozy 
studio near the old town, fully equipped 
and centrally located.', 94.9, 6, '2023-03-20');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (2, 2, 15, 2, 15, 'Sunny Loft with 
City View', 'A wonderful stay: sunny loft 
with city view, fully equipped and 
centrally located.', 227.55, 8, '2019-11-27');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (3, 3, 3, 3, 10, 'Modern Flat by the 
River', 'A wonderful stay: modern flat by 
the river, fully equipped and centrally 
located.', 181.9, 6, '2019-01-18');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (4, 4, 8, 4, 10, 'Charming Cottage 
Retreat', 'A wonderful stay: charming 
cottage retreat, fully equipped and 
centrally located.', 99.02, 4, '2019-08-27');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (5, 5, 1, 5, 2, 'Rooftop Apartment 
with Terrace', 'A wonderful stay: rooftop 
apartment with terrace, fully equipped and 
centrally located.', 104.78, 8, '2024-11-08');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (6, 6, 3, 6, 15, 'Quiet Room in 
Historic Building', 'A wonderful stay: 
quiet room in historic building, fully 
equipped and centrally located.', 153.12, 
4, '2026-01-21');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (7, 7, 13, 7, 16, 'Design Apartment 
close to Metro', 'A wonderful stay: design 
apartment close to metro, fully equipped 
and centrally located.', 148.9, 3, '2025-05-11');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (8, 8, 1, 8, 4, 'Family House with 
Garden', 'A wonderful stay: family house 
with garden, fully equipped and centrally 
located.', 256.85, 4, '2019-12-22');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (9, 9, 17, 9, 15, 'Chic Studio in 
Arts District', 'A wonderful stay: chic 
studio in arts district, fully equipped and 
centrally located.', 49.31, 4, '2019-05-13');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (10, 10, 15, 10, 5, 'Bright 
Apartment near Central Station', 'A 
wonderful stay: bright apartment near 
central station, fully equipped and 
centrally located.', 263.4, 6, '2022-12-18');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (11, 11, 20, 11, 17, 'Seaside View 
Apartment', 'A wonderful stay: seaside view 
apartment, fully equipped and centrally 
located.', 156.62, 8, '2019-10-14');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (12, 12, 16, 12, 15, 'Loft with 
Exposed Brick', 'A wonderful stay: loft 
with exposed brick, fully equipped and 
centrally located.', 108.87, 4, '2025-02-24');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (13, 13, 9, 13, 17, 'Elegant Flat in 
Old Quarter', 'A wonderful stay: elegant 
flat in old quarter, fully equipped and 
centrally located.', 173.11, 4, '2021-01-29');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (14, 14, 15, 14, 3, 'Minimalist 
Apartment Downtown', 'A wonderful stay: 
minimalist apartment downtown, fully 
equipped and centrally located.', 238.36, 
4, '2021-01-17');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (15, 15, 11, 15, 11, 'Traditional 
House with Courtyard', 'A wonderful stay: 
traditional house with courtyard, fully 
equipped and centrally located.', 289.51, 
2, '2019-07-21');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (16, 16, 5, 16, 8, 'Penthouse with 
Skyline View', 'A wonderful stay: penthouse 
with skyline view, fully equipped and 
centrally located.', 144.17, 3, '2025-12-03');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (17, 17, 7, 17, 3, 'Renovated Flat 
near University', 'A wonderful stay: 
renovated flat near university, fully 
equipped and centrally located.', 153.24, 
6, '2024-02-01');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (18, 18, 15, 18, 14, 'Cottage with 
Private Garden', 'A wonderful stay: cottage 
with private garden, fully equipped and 
centrally located.', 52.75, 7, '2022-05-15');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (19, 19, 19, 19, 1, 'Compact Studio 
for Solo Travelers', 'A wonderful stay: 
compact studio for solo travelers, fully 
equipped and centrally located.', 279.17, 
7, '2023-05-08');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (20, 20, 1, 20, 12, 'Spacious Duplex 
near Park', 'A wonderful stay: spacious 
duplex near park, fully equipped and 
centrally located.', 120.1, 7, '2022-09-13');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (21, 1, 18, 21, 18, 'Boutique 
Apartment with Balcony', 'A wonderful stay: 
boutique apartment with balcony, fully 
equipped and centrally located.', 262.96, 
4, '2023-06-23');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (22, 2, 8, 22, 9, 'Rustic House in 
Quiet Neighborhood', 'A wonderful stay: 
rustic house in quiet neighborhood, fully 
equipped and centrally located.', 159.21, 
1, '2022-05-12');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (23, 3, 11, 23, 13, 'Contemporary 
Flat with Workspace', 'A wonderful stay: 
contemporary flat with workspace, fully 
equipped and centrally located.', 241.39, 
8, '2019-06-07');
INSERT INTO Property (PropertyID, HostID, 
PropertyTypeID, AddressID, 
CancellationPolicyID, Title, Description, 
PricePerNight, MaxGuests, CreatedDate) 
VALUES (24, 4, 20, 24, 18, 'Airy Room with 
Shared Kitchen', 'A wonderful stay: airy 
room with shared kitchen, fully equipped 
and centrally located.', 42.69, 7, '2024-08-21');

-- PropertyPhoto
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (1,1, 'https://cdn.airbnbclone.example/property1_1.jpg', '2024-04-30', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (2, 1, 'https://cdn.airbnbclone.example/property1_2.jpg', '2025-06-08', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto)
VALUES (3, 2, 'https://cdn.airbnbclone.example/property2_1.jpg', '2018-04-22',1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto)
VALUES (4, 2, 'https://cdn.airbnbclone.example/property2_2.jpg', '2018-12-10', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (5, 3, 'https://cdn.airbnbclone.example/property3_1.jpg', '2025-03-17', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (6, 3, 'https://cdn.airbnbclone.example/property3_2.jpg', '2022-10-22', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (7, 4, 'https://cdn.airbnbclone.example/property4_1.jpg', '2019-07-10', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (8, 4, 'https://cdn.airbnbclone.example/property4_2.jpg', '2023-03-07', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto)
VALUES (9, 5, 'https://cdn.airbnbclone.example/property5_1.jpg', '2020-01-15', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto)
VALUES (10, 5, 'https://cdn.airbnbclone.example/property5_2.jpg', '2018-07-25', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (11, 6, 'https://cdn.airbnbclone.example/property6_1.jpg', '2020-12-01', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (12, 6, 'https://cdn.airbnbclone.example/property6_2.jpg', '2022-04-02', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (13, 7, 'https://cdn.airbnbclone.example/property7_1.jpg', '2021-09-02', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (14, 7, 'https://cdn.airbnbclone.example/property7_2.jpg', '2020-05-16', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (15, 8, 'https://cdn.airbnbclone.example/property8_1.jpg', '2023-02-06', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (16, 8,'https://cdn.airbnbclone.example/property8_2.jpg', '2021-08-31', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (17, 9, 'https://cdn.airbnbclone.example/property9_1.jpg', '2021-10-14', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (18, 9, 'https://cdn.airbnbclone.example/property9_2.jpg', '2022-04-02', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (19, 10, 'https://cdn.airbnbclone.example/property10_1.jpg', '2021-02-13', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (20, 10, 'https://cdn.airbnbclone.example/property10_2.jpg', '2022-09-23', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (21, 11, 'https://cdn.airbnbclone.example/property11_1.jpg', '2020-10-30', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (22, 11, 'https://cdn.airbnbclone.example/property11_2.jpg', '2018-12-02', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) VALUES (23, 12, 'https://cdn.airbnbclone.example/property12_1.jpg', '2023-04-11', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (24, 12,'https://cdn.airbnbclone.example/property12_2.jpg', '2018-03-21', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (25, 13,'https://cdn.airbnbclone.example/property13_1.jpg', '2026-05-27', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto)
VALUES (26, 13, 'https://cdn.airbnbclone.example/property13_2.jpg', '2024-01-19', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (27, 14, 'https://cdn.airbnbclone.example/property14_1.jpg', '2018-08-02', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (28, 14, 'https://cdn.airbnbclone.example/property14_2.jpg', '2021-12-04', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (29, 15,'https://cdn.airbnbclone.example/property15_1.jpg', '2020-07-07', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (30, 15,'https://cdn.airbnbclone.example/property15_2.jpg', '2025-04-16', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (31, 16,'https://cdn.airbnbclone.example/property16_1.jpg', '2018-10-09', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (32, 16,'https://cdn.airbnbclone.example/property16_2.jpg', '2025-04-23', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (33, 17,'https://cdn.airbnbclone.example/property17_1.jpg', '2018-06-14', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (34, 17,'https://cdn.airbnbclone.example/property17_2.jpg', '2018-05-08', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (35, 18,'https://cdn.airbnbclone.example/property18_1.jpg', '2020-10-09', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (36, 18,'https://cdn.airbnbclone.example/property18_2.jpg', '2020-03-27', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (37, 19,'https://cdn.airbnbclone.example/property19_1.jpg', '2018-03-25', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (38 , 19,'https://cdn.airbnbclone.example/property19_2.jpg', '2024-12-19', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (39 , 20,'https://cdn.airbnbclone.example/property20_1.jpg', '2019-09-17', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (40, 20,'https://cdn.airbnbclone.example/property20_2.jpg', '2020-09-04', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (41, 21,'https://cdn.airbnbclone.example/property21_1.jpg', '2019-06-02', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (42 , 21,'https://cdn.airbnbclone.example/property21_2.jpg', '2023-04-24', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto)
VALUES (43, 22,'https://cdn.airbnbclone.example/property22_1.jpg', '2025-07-05', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (44, 22,'https://cdn.airbnbclone.example/property22_2.jpg', '2019-04-14', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (45, 23,'https://cdn.airbnbclone.example/property23_1.jpg', '2024-04-29', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (46, 23,'https://cdn.airbnbclone.example/property23_2.jpg', '2020-06-11', 0);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (47, 24,'https://cdn.airbnbclone.example/property24_1.jpg', '2023-03-20', 1);
INSERT INTO PropertyPhoto (PhotoID, 
PropertyID, PhotoURL, UploadDate, 
IsCoverPhoto) 
VALUES (48, 24,'https://cdn.airbnbclone.example/property24_2.jpg', '2025-11-05', 0);

-- PropertyAmenity (M:N junction)
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (1, 9);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (1, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (1, 6);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (1, 4);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (2, 6);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (2, 10);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (2, 4);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (2, 1);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (3, 10);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (3, 19);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (3, 13);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (3, 18);
INSERT INTO PropertyAmenity (PropertyID,AmenityID)
VALUES (4, 7);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (4, 3);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (4, 8);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (4, 4);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (5, 10);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (5, 4);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (5, 2);
INSERT INTO PropertyAmenity (PropertyID,AmenityID)
VALUES (5, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (6, 18);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (6, 14);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (6, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID)
VALUES (6, 3);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (7, 17);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (7, 11);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (7, 1);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (7, 14);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (8, 16);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (8, 4);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (8, 14);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (8, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (9, 15);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (9, 5);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (9, 14);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (9, 6);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (10, 17);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (10, 9);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (10, 18);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (10, 16);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (11, 15);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (11, 14);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (11, 9);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (11, 11);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (12, 8);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (12, 3);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (12, 9);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (12, 15);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (13, 8);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (13, 15);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (13, 13);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (13, 11);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (14, 1);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (14, 16);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (14, 11);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (14, 6);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (15, 16);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (15, 7);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (15, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (15, 9);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (16, 11);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (16, 9);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (16, 19);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (16, 1);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (17, 17);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (17, 7);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (17, 3);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (17, 8);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (18, 14);
INSERT INTO PropertyAmenity (PropertyID, AmenityID) 
VALUES (18, 16);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (18, 18);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (18, 8);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (19, 16);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (19, 20);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (19, 15);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (19, 1);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (20, 3);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (20, 10);
INSERT INTO PropertyAmenity (PropertyID,AmenityID)
VALUES (20, 8);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (20, 13);
INSERT INTO PropertyAmenity (PropertyID,AmenityID)
VALUES (21, 8);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (21, 10);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (21, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (21, 16);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (22, 18);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (22, 17);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (22, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (22, 14);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (23, 18);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (23, 11);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (23, 12);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (23, 15);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (24, 9);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (24, 10);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (24, 20);
INSERT INTO PropertyAmenity (PropertyID,AmenityID) 
VALUES (24, 8);

-- PromoCode
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (1, 'STAY2021', 5, '2026-01-05', '2026-07-04');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (2, 'STAY2022', 10, '2025-06-11', '2025-12-08');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (3, 'STAY2023', 5, '2026-01-16', '2026-07-15');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (4, 'STAY2024', 10, '2025-04-09', '2025-10-06');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (5, 'STAY2025', 10, '2026-01-14', '2026-07-13');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (6, 'STAY2026', 20, '2025-05-22', '2025-11-18');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (7, 'STAY2027', 15, '2025-02-21', '2025-08-20');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (8, 'STAY2028', 10, '2025-06-01','2025-11-28');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (9, 'STAY2029', 10, '2025-07-04','2025-12-31');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (10, 'STAY2030', 10, '2025-06-04','2025-12-01');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (11, 'STAY2031', 5, '2025-12-29', '2026-06-27');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (12, 'STAY2032', 10, '2025-05-21', '2025-11-17');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (13, 'STAY2033', 5, '2025-01-28','2025-07-27');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (14, 'STAY2034', 15, '2025-12-24', '2026-06-22');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (15, 'STAY2035', 10, '2025-11-23', '2026-05-22');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (16, 'STAY2036', 20, '2025-02-22', '2025-08-21');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (17, 'STAY2037', 5, '2025-10-21', '2026-04-19');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (18, 'STAY2038', 15, '2025-08-29', '2026-02-25');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (19, 'STAY2039', 20, '2025-08-14', '2026-02-10');
INSERT INTO PromoCode (PromoCodeID, Code, DiscountPercentage, ValidFrom, ValidTo) 
VALUES (20, 'STAY2040', 15, '2025-04-05', '2025-10-02');

-- Booking
INSERT INTO Booking (BookingID, PropertyID, GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (1, 2, 9, 16, '2024-04-26', '2024-04-29', 4, 'Completed', '2024-03-23');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate)
VALUES (2, 3, 19, 2, '2024-06-04', '2024-06-08', 3, 'Completed', '2024-05-27');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (3, 8, 4, 18, '2026-02-21', '2026-03-01', 2, 'Completed', '2025-12-31');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (4, 17, 13, 15, '2026-07-19', '2026-07-28', 3, 'Completed', '2026-05-22');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (5, 19, 14, 10, '2025-08-05', '2025-08-07', 1, 'Completed', '2025-06-15');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (6, 7, 21, 7, '2024-09-27', '2024-09-30', 2, 'Confirmed', '2024-09-09');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (7, 6, 18, 3, '2024-06-09', '2024-06-11', 4, 'Completed', '2024-05-09');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (8, 23, 20, 16, '2024-10-25', '2024-10-27', 2, 'Cancelled', '2024-10-04');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (9, 23, 10, 15, '2024-03-13', '2024-03-18', 3, 'Confirmed', '2024-01-20');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (10, 21, 19, 7, '2025-03-11', '2025-03-14', 2, 'Completed', '2025-01-26');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (11, 5, 30, 9, '2026-04-26', '2026-04-30', 1, 'Cancelled', '2026-04-20');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (12, 6, 26, 10, '2025-09-01', '2025-09-07', 4, 'Confirmed', '2025-08-22');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (13, 15, 23, 10, '2025-12-17', '2025-12-25', 3, 'Completed', '2025-11-12');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (14, 18, 16, 15, '2024-03-23', '2024-03-25', 4, 'Cancelled', '2024-02-02');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (15, 11, 20, 9, '2024-01-27', '2024-01-30', 2, 'Confirmed', '2023-12-12');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (16, 19, 19, 1, '2026-02-22', '2026-02-28', 1, 'Completed', '2026-01-02');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (17, 6, 16, 17, '2025-10-29', '2025-11-07', 3, 'Cancelled', '2025-10-15');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (18, 19, 14, 16, '2024-04-03', '2024-04-12', 3, 'Confirmed', '2024-03-05');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (19, 11, 11, 4, '2026-05-28', '2026-06-01', 3, 'Completed', '2026-04-29');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (20, 23, 16, 10, '2025-11-09', '2025-11-17', 1, 'Cancelled', '2025-10-08');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (21, 3, 11, 9, '2024-11-27', '2024-11-30', 4, 'Confirmed', '2024-09-30');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (22, 17, 27, 1, '2025-11-04', '2025-11-14', 4, 'Completed', '2025-10-06');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (23, 2, 7, 17, '2025-01-05', '2025-01-14', 4, 'Cancelled', '2024-11-15');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (24, 2, 7, 9, '2025-07-16', '2025-07-20', 3, 'Confirmed', '2025-06-15');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (25, 23, 16, 4, '2024-01-30', '2024-02-04', 2, 'Completed', '2024-01-08');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (26, 18, 1, 18, '2025-02-21', '2025-02-24', 2, 'Cancelled', '2024-12-27');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (27, 4, 15, 4, '2025-10-25', '2025-10-29', 4, 'Confirmed', '2025-09-07');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (28, 10, 17, 9, '2025-03-01', '2025-03-10', 4, 'Completed', '2025-02-11');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (29, 15, 18, 5, '2025-01-27', '2025-02-01', 2, 'Cancelled', '2024-11-30');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (30, 3, 9, 14, '2024-12-14', '2024-12-24', 3, 'Confirmed', '2024-10-20');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (31, 1, 10, 10, '2026-05-07', '2026-05-16', 2, 'Completed', '2026-04-06');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (32, 18, 16, 12, '2024-12-06', '2024-12-16', 4, 'Cancelled', '2024-11-04');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (33, 11, 28, 7, '2025-12-15', '2025-12-20', 4, 'Confirmed', '2025-11-28');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (34, 14, 2, 11, '2026-02-01', '2026-02-10', 4, 'Completed', '2026-01-05');
INSERT INTO Booking (BookingID, PropertyID, 
GuestID, CurrencyID, CheckInDate, 
CheckOutDate, NumGuests, BookingStatus, 
BookingDate) 
VALUES (35, 22, 26, 5, '2025-05-22', '2025-05-24', 2, 'Cancelled', '2025-04-17');

-- BookingPromo (M:N junction)
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (22, 1);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (7, 2);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (29, 3);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (34, 4);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (17, 5);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (30, 6);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (15, 7);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (1, 8);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (24, 9);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (5, 10);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (14, 11);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (21, 12);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (26, 13);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (3, 14);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (16, 15);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (9, 16);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (11, 17);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (13, 18);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (35, 19);
INSERT INTO BookingPromo (BookingID, PromoCodeID) 
VALUES (19, 20);

-- Payment (TRIPLE relationship: Booking + Guest[payer] + Host[payee])
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus)
VALUES (1, 1, 9, 2, 2142.67, '2024-04-21', '2024-04-27', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (2, 2, 19, 3, 999.62, '2024-06-01', '2024-06-05', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (3, 3, 4, 8, 1596.85, '2026-02-17', '2026-02-22', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus)
VALUES (4, 4, 13, 17, 2191.17, '2026-07-18', '2026-07-20', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (5, 5, 14, 19, 1574.25, '2025-08-03', '2025-08-06', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus)
VALUES (6, 6, 21, 7, 1607.41, '2024-09-24', '2024-09-28', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (7, 7, 18, 6, 2493.77, '2024-06-08', '2024-06-10', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (8, 8, 20, 3, 1130.21, '2024-10-24', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (9, 9, 10, 3, 1920.09, '2024-03-12', '2024-03-14', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (10, 10, 19, 1, 1153.7, '2025-03-08', '2025-03-12', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (11, 11, 30, 5, 2266.29, '2026-04-25', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (12, 12, 26, 6, 864.99, '2025-08-31', '2025-09-02', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (13, 13, 23, 15, 789.95, '2025-12-14', '2025-12-18', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (14, 14, 16, 18, 1122.26, '2024-03-21', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (15, 15, 20, 11, 1365.42, '2024-01-22', '2024-01-28', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (16, 16, 19, 19, 1729.96, '2026-02-20', '2026-02-23', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (17, 17, 16, 6, 491.36, '2025-10-28', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (18, 18, 14, 19, 1554.97, '2024-03-30', '2024-04-04', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (19, 19, 11, 11, 1579.7, '2026-05-26', '2026-05-29', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (20, 20, 16, 3, 1284.35, '2025-11-04', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (21, 21, 11, 3, 426.34, '2024-11-23', '2024-11-28', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (22, 22, 27, 17, 1623.73, '2025-10-31', '2025-11-05', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (23, 23, 7, 2, 697.89, '2025-01-04', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (24, 24, 7, 2, 2255.36, '2025-07-12', '2025-07-17', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (25, 25, 16, 3, 2260.93, '2024-01-25', '2024-01-31', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (26, 26, 1, 18, 462.3, '2025-02-17', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (27, 27, 15, 4, 2367.47, '2025-10-20', '2025-10-26', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (28, 28, 17, 10, 803.95, '2025-02-25', '2025-03-02', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (29, 29, 18, 15, 1750.56, '2025-01-23', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (30, 30, 9, 3, 2125.64, '2024-12-12', '2024-12-15', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (31, 31, 10, 1, 2498.48, '2026-05-03', '2026-05-08', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (32, 32, 16, 18, 338.1, '2024-12-02', NULL, 'Refunded');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (33, 33, 28, 11, 1464.05, '2025-12-10', '2025-12-16', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (34, 34, 2, 14, 796.01, '2026-01-29', '2026-02-02', 'Paid');
INSERT INTO Payment (PaymentID, BookingID, GuestID, HostID, Amount, PaymentDate, PayoutDate, PaymentStatus) 
VALUES (35, 35, 26, 2, 133.09, '2025-05-18', NULL, 'Refunded');


-- Commission
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (1, 1, 7.65, 3.0, 115.36);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (2, 2, 10.11, 3.0, 150.21);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (3, 3, 6.29, 3.0, 123.25);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (4, 4, 8.98, 3.0, 181.31);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (5, 5, 7.72, 3.0, 160.78);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (6, 6, 9.64, 3.0, 73.7);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (7, 7, 9.82, 3.0, 126.07);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (8, 8, 10.07, 3.0, 145.58);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (9, 9, 9.96, 3.0, 168.48);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (10, 10, 9.77, 3.0, 181.16);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (11, 11, 9.88, 3.0, 65.24);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (12, 12, 8.64, 3.0, 118.02);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (13, 13, 10.39, 3.0, 22.58);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (14, 14, 7.77, 3.0, 150.76);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (15, 15, 7.05, 3.0, 30.77);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (16, 16, 9.24, 3.0, 194.44);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (17, 17, 9.19, 3.0, 183.13);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (18, 18, 10.98, 3.0, 55.11);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (19, 19, 10.95, 3.0, 98.96);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (20, 20, 10.84, 3.0, 150.58);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (21, 21, 8.03, 3.0, 27.46);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (22, 22, 11.78, 3.0, 32.45);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (23, 23, 11.8, 3.0, 172.73);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (24, 24, 10.35, 3.0, 196.09);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (25, 25, 11.8, 3.0, 161.89);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (26, 26, 8.19, 3.0, 159.18);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (27, 27, 6.08, 3.0, 109.63);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (28, 28, 8.73, 3.0, 136.2);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (29, 29, 10.03, 3.0, 118.99);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (30, 30, 10.93, 3.0, 188.36);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (31, 31, 6.65, 3.0, 50.6);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (32, 32, 6.15, 3.0, 177.43);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (33, 33, 9.37, 3.0, 183.47);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (34, 34, 7.33, 3.0, 17.33);
INSERT INTO Commission (CommissionID, PaymentID, GuestCommissionPct, HostCommissionPct, CommissionAmount) 
VALUES (35, 35, 10.94, 3.0, 182.33);

-- Review (TRIPLE relationship: Booking + Reviewer + Reviewee)
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (1, 1, 29, 2, 4, 'Great stay, would book again.', '2024-05-05');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (2, 1, 2, 29, 5, 'Respectful guest, left the place tidy.', '2024-05-05');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (3, 2, 39, 3, 3, 'Great stay, would book again.', '2024-06-10');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (4, 2, 3, 39, 4, 'Respectful guest, left the place tidy.', '2024-06-10');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (5, 3, 24, 8, 3, 'Great stay, would book again.', '2026-03-04');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate)
 VALUES (6, 3, 8, 24, 5, 'Respectful guest, left the place tidy.', '2026-03-04');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (7, 4, 33, 17, 3, 'Great stay, would book again.', '2026-07-29');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (8, 4, 17, 33, 4, 'Respectful guest, left the place tidy.', '2026-07-29');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (9, 5, 34, 19, 5, 'Great stay, would book again.', '2025-08-09');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (10, 5, 19, 34, 5, 'Respectful guest, left the place tidy.', '2025-08-09');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (11, 7, 38, 6, 4, 'Great stay, would book again.', '2024-06-14');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (12, 7, 6, 38, 5, 'Respectful guest, left the place tidy.', '2024-06-14');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (13, 10, 39, 1, 5, 'Great stay, would book again.', '2025-03-20');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (14, 10, 1, 39, 4, 'Respectful guest, left the place tidy.', '2025-03-20');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (15, 13, 43, 15, 4, 'Great stay, would book again.', '2025-12-31');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (16, 13, 15, 43, 4, 'Respectful guest, left the place tidy.', '2025-12-31');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (17, 16, 39, 19, 4, 'Great stay, would book again.', '2026-03-05');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (18, 16, 19, 39, 5, 'Respectful guest, left the place tidy.', '2026-03-05');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (19, 19, 31, 11, 4, 'Great stay, would book again.', '2026-06-02');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (20, 19, 11, 31, 5, 'Respectful guest, left the place tidy.', '2026-06-02');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (21, 22, 47, 17, 3, 'Great stay, would book again.', '2025-11-18');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (22, 22, 17, 47, 5, 'Respectful guest, left the place tidy.', '2025-11-18');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (23, 25, 36, 3, 3, 'Great stay, would book again.', '2024-02-11');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (24, 25, 3, 36, 5, 'Respectful guest, left the place tidy.', '2024-02-11');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (25, 28, 37, 10, 3, 'Great stay, would book again.', '2025-03-16');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (26, 28, 10, 37, 5, 'Respectful guest, left the place tidy.', '2025-03-16');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (27, 31, 30, 1, 5, 'Great stay, would book again.', '2026-05-22');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (28, 31, 1, 30, 5, 'Respectful guest, left the place tidy.', '2026-05-22');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (29, 34, 22, 14, 3, 'Great stay, would book again.', '2026-02-14');
INSERT INTO Review (ReviewID, BookingID, ReviewerUserID, RevieweeUserID, Rating, Comment, ReviewDate) 
VALUES (30, 34, 14, 22, 5, 'Respectful guest, left the place tidy.', '2026-02-14');

-- Message (TRIPLE relationship: Sender + Receiver + Property)
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (1, 7, 24, 7, 'Yes, it''s available! Feel free to book.', '2026-04-11 02:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (2, 41, 1, 21, 'What time is check-in?', '2025-01-22 01:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (3, 8, 25, 8, 'Check-in is any time after 3PM.', '2025-07-30 02:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (4, 27, 18, 18, 'Could I bring an extra guest?', '2025-08-10 07:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (5, 5, 46, 5, 'Sure, just let me know the total headcount.', '2025-01-03 08:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (6, 25, 5, 5, 'Thanks for a wonderful stay!', '2025-09-14 05:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (7, 1, 25, 1, 'You''re welcome, come back anytime.', '2025-01-16 11:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (8, 39, 8, 8, 'Is parking available nearby?', '2025-11-28 00:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (9, 2, 25, 2, 'Yes, free street parking is available.', '2026-03-08 16:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (10, 36, 3, 3, 'Can I get an early check-in?', '2026-04-05 11:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (11, 4, 35, 4, 'I''ll check with the cleaning crew and confirm.', '2026-05-31 07:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (12, 44, 2, 2, 'Hi, is the property available for these dates?', '2026-06-18 09:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (13, 1, 22, 1, 'Yes, it''s available! Feel free to book.', '2026-05-06 12:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (14, 36, 4, 4, 'What time is check-in?', '2026-03-31 02:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (15, 11, 40, 11, 'Check-in is any time after 3PM.', '2025-06-01 02:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (16, 41, 20, 20, 'Could I bring an extra guest?', '2025-11-29 12:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (17, 17, 30, 17, 'Sure, just let me know the total headcount.', '2026-04-10 16:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (18, 46, 4, 4, 'Thanks for a wonderful stay!', '2025-04-28 20:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (19, 18, 44, 18, 'You''re welcome, come back anytime.', '2025-08-09 13:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (20, 34, 8, 8, 'Is parking available nearby?', '2025-12-14 14:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (21, 4, 24, 24, 'Yes, free street parking is available.', '2025-11-17 13:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (22, 32, 9, 9, 'Can I get an early check-in?', '2025-06-06 21:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (23, 3, 23, 3, 'I''ll check with the cleaning crew and confirm.', '2025-03-29 02:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (24, 44, 4, 24, 'Hi, is the property available for these dates?', '2026-01-17 04:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (25, 19, 38, 19, 'Yes, it''s available! Feel free to book.', '2025-12-04 21:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (26, 48, 12, 12, 'What time is check-in?', '2026-03-10 23:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (27, 10, 40, 10, 'Check-in is any time after 3PM.', '2025-11-16 11:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (28, 27, 17, 17, 'Could I bring an extra guest?', '2025-06-08 21:00:00', 1);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (29, 4, 32, 4, 'Sure, just let me know the total headcount.', '2026-01-12 03:00:00', 0);
INSERT INTO Message (MessageID, SenderUserID, ReceiverUserID, PropertyID, MessageText, SentDate, IsRead) 
VALUES (30, 28, 19, 19, 'Thanks for a wonderful stay!', '2026-03-16 17:00:00', 0);

-- Wishlist
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (1, 1, 'Weekend getaways', '2026-02-14');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (2, 2, 'Bucket list', '2023-02-23');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (3, 3, 'City breaks', '2026-06-01');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (4, 4, 'Someday', '2024-07-01');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (5, 5, 'Family holiday', '2023-03-01');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (6, 6, 'Romantic escapes', '2024-01-05');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (7, 7, 'Ski trips', '2024-07-13');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate)
VALUES (8, 8, 'Beach houses', '2024-09-24');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (9, 9, 'Work retreats', '2024-11-26');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (10, 10, 'Summer trip', '2024-12-19');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate)
VALUES (11, 11, 'Weekend getaways', '2023-01-13');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (12, 12, 'Bucket list', '2024-01-07');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (13, 13, 'City breaks', '2023-10-21');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (14, 14, 'Someday', '2026-03-05');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (15, 15, 'Family holiday', '2025-03-31');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate)
VALUES (16, 16, 'Romantic escapes', '2023-05-23');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate)
 VALUES (17, 17, 'Ski trips', '2023-10-18');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate)
VALUES (18, 18, 'Beach houses', '2023-03-04');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (19, 19, 'Work retreats', '2023-07-07');
INSERT INTO Wishlist (WishlistID, GuestID, WishlistName, CreatedDate) 
VALUES (20, 20, 'Summer trip', '2025-12-22');

-- Dataset input for WishlistItem Table (M:N Relationship)
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (7, 13, '2025-05-09');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (15, 11, '2023-11-19');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (12, 10, '2024-10-26');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (19, 20, '2023-06-23');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (2, 5, '2023-11-19');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (20, 2, '2023-06-17');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (9, 15, '2025-05-18');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (16, 20, '2025-06-24');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (14, 9, '2024-03-17');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (17, 4, '2024-12-07');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate)
VALUES (14, 4, '2024-08-03');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (19, 16, '2025-12-15');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (10, 2, '2024-03-27');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (13, 20, '2023-04-23');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (1, 7, '2024-09-09');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (7, 5, '2024-06-07');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (10, 11, '2023-09-03');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (1, 16, '2025-05-31');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (6, 5, '2025-02-17');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (18, 23, '2024-04-16');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (17, 18, '2024-12-26');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (3, 13, '2023-03-28');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (14, 1, '2025-07-30');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (3, 11, '2026-03-25');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (14, 19, '2025-04-08');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (14, 10, '2023-08-24');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (13, 1, '2024-10-27');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (6, 20, '2025-07-31');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (12, 3, '2025-06-13');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (4, 8, '2025-06-11');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (19, 13, '2025-12-09');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (10, 24, '2024-11-26');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (8, 11, '2023-12-11');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (3, 17, '2023-08-22');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (17, 17, '2024-02-02');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (12, 12, '2023-10-30');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (8, 4, '2023-10-27');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (9, 7, '2023-12-22');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (20, 5, '2023-06-04');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (6, 21, '2025-10-08');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (15, 19, '2026-04-01');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (15, 22, '2026-03-02');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (20, 11, '2024-10-09');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (5, 15, '2023-05-20');
INSERT INTO WishlistItem (WishlistID, PropertyID, AddedDate) 
VALUES (16, 15, '2024-09-12');

-- Dataset input for IncomeEstimate Table
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (1, 1, 3705.69, 72.53, '2025-12-27');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (2, 2, 2578.61, 57.07, '2026-04-08');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (3, 3, 746.67, 60.28, '2025-10-21');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (4, 4, 899.25, 87.53, '2025-04-03');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (5, 5, 2998.53, 67.89, '2026-04-19');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (6, 6, 2863.28, 92.48, '2025-02-12');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (7, 7, 2353.96, 84.54, '2025-07-12');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (8, 8, 1853.95, 66.16, '2025-06-04');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (9, 9, 4335.12, 64.78, '2025-12-18');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (10, 10, 4431.3, 44.64, '2025-06-26');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (11, 11, 752.65, 78.92, '2026-03-26');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (12, 12, 2643.87, 73.54, '2026-01-08');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (13, 13, 2054.12, 55.56, '2026-02-23');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate)
VALUES (14, 14, 3620.41, 77.34, '2025-02-23');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (15, 15, 3677.99, 75.6, '2025-03-09');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (16, 16, 1885.79, 70.69, '2026-01-31');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (17, 17, 1708.17, 79.81, '2025-06-03');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (18, 18, 1900.11, 72.05, '2025-05-25');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (19, 19, 4175.31, 57.06, '2026-02-06');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (20, 20, 1102.91, 78.99, '2025-03-28');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (21, 21, 1807.37, 60.72, '2025-12-03');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (22, 22, 3771.42, 76.86, '2025-04-06');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (23, 23, 3119.5, 63.29, '2026-01-06');
INSERT INTO IncomeEstimate 
(IncomeEstimateID, PropertyID, EstimatedMonthlyIncome, OccupancyRatePct, EstimateDate) 
VALUES (24, 24, 671.1, 56.99, '2025-08-08');

-- Dataset input for Notification Table.
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (1, 22, 'NewMessage', 'You have a new message.', '2026-05-13 06:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (2, 9, 'ReviewReceived', 'You received a new review.', '2025-06-08 02:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (3, 7, 'Payout', 'A payout has been sent to your account.', '2026-06-04 17:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (4, 34, 'PromoAvailable', 'A new promo code is available for your next trip.', '2025-02-08 21:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (5, 50, 'BookingConfirmed', 'Your booking has been confirmed.', '2025-05-15 19:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (6, 11, 'NewMessage', 'You have a new message.', '2025-07-05 22:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (7, 11, 'ReviewReceived', 'You received a new review.', '2026-03-25 01:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (8, 44, 'Payout', 'A payout has been sent to your account.', '2025-09-01 14:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead)
VALUES (9, 49, 'PromoAvailable', 'A new promo code is available for your next trip.', '2026-04-05 07:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (10, 20, 'BookingConfirmed', 'Your booking has been confirmed.', '2026-04-26 06:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (11, 37, 'NewMessage', 'You have a new message.', '2026-03-28 14:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (12, 50, 'ReviewReceived', 'You received a new review.', '2026-01-27 16:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (13, 11, 'Payout', 'A payout has been sent to your account.', '2025-07-24 19:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (14, 17, 'PromoAvailable', 'A new promo code is available for your next trip.', '2025-02-23 20:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead)
VALUES (15, 24, 'BookingConfirmed', 'Your booking has been confirmed.', '2025-04-16 22:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (16, 8, 'NewMessage', 'You have a new message.', '2025-10-19 02:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (17, 18, 'ReviewReceived', 'You received a new review.', '2026-04-06 16:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (18, 28, 'Payout', 'A payout has been sent to your account.', '2025-04-04 07:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (19, 23, 'PromoAvailable', 'A new promo code is available for your next trip.', '2025-01-28 13:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (20, 33, 'BookingConfirmed', 'Your booking has been confirmed.', '2026-01-18 07:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (21, 6, 'NewMessage', 'You have a new message.', '2026-01-19 07:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (22, 7, 'ReviewReceived', 'You received a new review.', '2025-12-10 04:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (23, 19, 'Payout', 'A payout has been sent to your account.', '2026-04-29 22:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (24, 49, 'PromoAvailable', 'A new promo code is available for your next trip.', '2026-04-26 14:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (25, 6, 'BookingConfirmed', 'Your booking has been confirmed.', '2025-01-20 08:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (26, 10, 'NewMessage', 'You have a new message.', '2026-06-25 13:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (27, 19, 'ReviewReceived', 'You received a new review.', '2025-09-01 09:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (28, 16, 'Payout', 'A payout has been sent to your account.', '2026-03-06 20:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (29, 30, 'PromoAvailable', 'A new promo code is available for your next trip.', '2025-03-06 03:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (30, 32, 'BookingConfirmed', 'Your booking has been confirmed.', '2025-01-17 20:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (31, 16, 'NewMessage', 'You have a new message.', '2025-05-28 09:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (32, 40, 'ReviewReceived', 'You received a new review.', '2025-12-28 07:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (33, 12, 'Payout', 'A payout has been sent to your account.', '2025-03-29 16:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (34, 5, 'PromoAvailable', 'A new promo code is available for your next trip.', '2026-06-23 17:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (35, 33, 'BookingConfirmed', 'Your booking has been confirmed.', '2025-01-21 12:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (36, 3, 'NewMessage', 'You have a new message.', '2026-02-01 11:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (37, 2, 'ReviewReceived', 'You received a new review.', '2026-01-01 02:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead)
VALUES (38, 47, 'Payout', 'A payout has been sent to your account.', '2025-04-17 18:00:00', 0);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead) 
VALUES (39, 22, 'PromoAvailable', 'A new promo code is available for your next trip.', '2025-05-17 01:00:00', 1);
INSERT INTO Notification (NotificationID, UserID, NotificationType, Message, CreatedDate, IsRead)
VALUES (40, 22, 'BookingConfirmed', 'Your booking has been confirmed.', '2025-06-29 21:00:00', 1);

-- This line of code statement ensures working and having access to all the tables.l
USE AirbnbDataMart; 

-- Inspect and load each respective tables in airbnbmart database for data validation, integrity and completeness.
-- Inspect and load currency table.
SELECT * FROM currency;
-- Inspect and load payoutmethod table.
SELECT * FROM payoutmethod;
-- inspect and load propertytype table.
SELECT * FROM propertytype;
-- inspect and load address table.
SELECT * FROM address;
-- inspect and check cancellationpolicy table.
SELECT * FROM cancellationpolicy;
-- Inspect and check amenity table.
SELECT * FROM amenity;
-- inspect and check top 20 useraccount table.
SELECT * FROM useraccount
LIMIT 20;

-- Inspect and check guestprofile.
SELECT * FROM guestprofile;
-- Inspect and check hostprofile table
SELECT * FROM hostprofile;
-- Inspect and check socialnetworklink table.
SELECT * FROM socialnetworklink;
-- inspect and load property table.
SELECT * FROM property;
-- Inspect and check propertyphoto table.
SELECT * FROM propertyphoto;
-- Inspect and check top 20 propertyamenity table.
SELECT * FROM propertyamenity
LIMIT 20;

-- Inspect and load promocode table.
SELECT * FROM promocode;
-- Inspect and check top 20 booking table.
SELECT * FROM booking
LIMIT 20;
-- Inspect and load bookingpromo
SELECT * FROM bookingpromo;
-- inspect and load payment table.
SELECT * FROM payment;
-- Highlight 10 guests who had made payment and their assigned hosts.
SELECT 
b.BookingID, u1.FirstName AS Guest, u2.FirstName AS Host, p.Amount, p.PaymentStatus
FROM 
Payment p
JOIN Booking b ON p.BookingID = b.BookingID
JOIN GuestProfile g ON p.GuestID = g.GuestID
JOIN UserAccount u1 ON g.UserID = u1.UserID
JOIN HostProfile h ON p.HostID = h.HostID
JOIN UserAccount u2 ON h.UserID = u2.UserID
WHERE p.PaymentStatus = 'Paid'
LIMIT 10;

-- Inspect and load commission table.
SELECT * FROM commission;

-- Highlight ten commission accross the table to ensure relationship.
SELECT c.PaymentID, p.Amount, c.GuestCommissionPct, c.HostCommissionPct,c.CommissionAmount
FROM Commission c
JOIN Payment p ON c.PaymentID = p.PaymentID 
LIMIT 10;

-- Inspect and load review table.
SELECT * FROM review;

-- Highlight 10 reviewer and reviewer and their respectives rating
SELECT r.ReviewID, b.BookingID, u1.FirstName AS Reviewer, u2.FirstName AS Reviewee, r.Rating
FROM Review r
JOIN Booking b ON r.BookingID = b.BookingID
JOIN UserAccount u1 ON r.ReviewerUserID = u1.UserID
JOIN UserAccount u2 ON r.RevieweeUserID = u2.UserID
LIMIT 20;

-- inspect and load message table.
SELECT * FROM message;

-- Ensure relationships within tables for top 20  overview of messages.
SELECT m.MessageID, s.FirstName AS Sender, rcv.FirstName AS Receiver, pr.Title AS Property
FROM Message m
JOIN UserAccount s ON m.SenderUserID = s.UserID
JOIN UserAccount rcv ON m.ReceiverUserID = rcv.UserID
JOIN Property pr ON m.PropertyID = pr.PropertyID
LIMIT 20;

-- inspect and load wishlist table.
SELECT * FROM wishlist;
-- inspect and load wishlistitem table.
SELECT * FROM wishlistitem;

-- Ensure relationship and an overview of top 20 type of wishlist a guest might want.
SELECT wi.WishlistID, w.WishlistName, p.Title AS Property FROM WishlistItem wi
JOIN Wishlist w ON wi.WishlistID = w.WishlistID
JOIN Property p ON wi.PropertyID = p.PropertyID
LIMIT 20;

-- Inspect and load incomeestimate table.
SELECT * FROM incomeestimate; 
-- Inspect and load top 20 notification table.
SELECT * FROM notification
LIMIT 20;


